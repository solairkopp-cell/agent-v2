class Stop_Delivery:
    def __init__(self, ID_stop, ID_delivery):
        self.ID_stop = ID_stop,
        self.ID_delivery = ID_delivery
    def __self__(self):
        return f"Stop_Delivery(ID_stop={self.ID_stop}, ID_delivery={self.ID_delivery})"